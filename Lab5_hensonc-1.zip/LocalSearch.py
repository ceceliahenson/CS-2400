import math
import random
from Problem import *


def Hill_Climbing(problem: Problem, initial: T):
    """
    Hill Climbing search
    :param problem: Class that possess search operators
    :return: returns a state that is a local maximum
    """
    current = initial
    while True:
        # [[0,0,1,0],[1,1,1,0],[1,0,0,0],[1,0,1,1]]
        neighbors_state = problem.successors(current)
        best = max(neighbors_state, key=problem.evaluation)
        if problem.evaluation(best) <= problem.evaluation(current):
            return current
        current = best


def Simulated_Annealing(problem: Problem, schedule, initial: T):
    """
    Simulated Annealing
    :param problem: Class that possess search operators
    :return: returns a state that is a local maximum
    """
    current = initial
    t = 1
    while True:
        T = schedule(t)
        if T == 0 or problem.evaluation(current) == 1:
            return current
        next = random.choice(problem.successors(current))
        E = problem.evaluation(next) - problem.evaluation(current)
        if E > 0:
            current = next
        else:
            probability = math.exp(E / T)
            if random.random() < probability:
                current = next
        t += 1


def Genetic_Algorithm(problem: Problem, initial: List[List[T]], num_epochs: int = 10, ):
    """
    Genetic Algorithm implementation
    :param problem: Class the posses attributes for the initial population and methods for GA operator
    :param initial: Initial population
    :param num_epochs: How many iterations to
    :return: Individual with the best fitness found after num_epochs or until a solution is found
    """
    # TODO - Implement a Genetic Algorithm based on the lecture and provided psuedocode
    counter = 0
    population = initial
    #print("epoch 0")
    #print(population)
    while counter < num_epochs:
        weights = []
        for individual in population:
            weights.append(problem.evaluation(individual))

        if 1 in weights:
            return population[weights.index(1)]
        #print(max(weights))
        population_two = []
        for i in range(len(population)):
            parent1, parent2 = problem.selection(population, weights, 2)
            child = problem.crossover(parent1, parent2)
            #print("crossover")
            #print(child)
            child = problem.mutate(child)
            #print("mutate")
            #print(child)

            population_two.append(child)
        population = population_two
        #print("epoch " + str(counter))
        #print(population)
        counter += 1

    return max(enumerate(population), key=lambda x: problem.fitness_proportionate_selection(x[1], weights))[1]

