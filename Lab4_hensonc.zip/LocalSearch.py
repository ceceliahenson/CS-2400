import math

from Problem import *

MAX_FITNESS = 1


def Hill_Climbing(problem: Problem, initial: T):
    """
    Hill Climbing
    :param problem: Class that possess search operators
    :return: returns a state that is a local maximum
    """

    # TODO - Implement Hill Climbing.

    # stubbed value so code compiles and runs
    # should be changed in final implementation

    current = initial
    while True:
        # [[0,0,1,0],[1,1,1,0],[1,0,0,0],[1,0,1,1]]
        neighbors_state = problem.successors(current)
        best = max(neighbors_state, key=problem.evaluation)
        if problem.evaluation(best) <= problem.evaluation(current):
            return current
        current = best


def Simulated_Annealing(problem: Problem, schedule, initial: T):
    """
    Simulated Annealing
    :param problem: Class that possess search operators
    :return: returns a state that is a local maximum
    """
    # TODO - Implement Simulated Annealing.

    # stubbed value so code compiles and runs
    # should be changed in final implementation
    current = initial
    t = 1
    while True:
        T = schedule(t)
        if T == 0 or problem.evaluation(current) == MAX_FITNESS:
            return current
        next = random.choice(problem.successors(current))
        E = problem.evaluation(next) - problem.evaluation(current)
        if E > 0:
            current = next
        else:
            probability = math.exp(E / T)
            if random.random() < probability:
                current = next
        t += 1
